package fiap.com.br.MarineMentor.controller;
import fiap.com.br.MarineMentor.entity.Artigo;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@RestController
public class ArtigoController {

    private List<Artigo> artigos = new ArrayList<>();

    // Método para LISTAR os ARTIGOS
    @GetMapping("/artigos")
    public List<Artigo> listarArtigos() {
        return artigos;
    }

    // Método para CRIAR um ARTIGO novo
    @PostMapping("/artigos/add")
    public Artigo criarArtigo(@RequestBody Artigo artigo) {
        artigo.setId_artigo( generateNextId() );
        artigos.add(artigo);
        return artigo;
    }

    // Método para ATUALIZAR algum ARTIGO
    @PutMapping("/artigos/atualizar/{id}")
    public Artigo atualizarArtigo(@PathVariable Long id, @RequestBody Artigo artigo) {
        Artigo artigoExistente = artigos.stream()
                .filter(u -> u.getId_artigo().equals(id))
                .findFirst()
                .orElseThrow( () -> new IllegalArgumentException("Artigo não encontrado no método: atualizarArtigo com o ID: " + id));

        artigoExistente.setTitulo(artigo.getTitulo());
        artigoExistente.setConteudo(artigo.getConteudo());
        artigoExistente.setAutor(artigo.getAutor());
        artigoExistente.setData_publicacao(artigo.getData_publicacao());
        artigoExistente.setVisualizacoes(artigo.getVisualizacoes());
        return artigoExistente;
    }

    // Método para DELETAR um ARTIGO
    @DeleteMapping("/artigos/delete/{id}")
    public void excluirArtigo(@PathVariable Long id) {
        artigos.removeIf( u -> u.getId_artigo().equals(id));
    }

    // Método para listar um ARTIGO por ID especifico
    @GetMapping("/artigos/buscarid/{id}")
    public Artigo buscarArtigoPorId(@PathVariable Long id) {
        return artigos.stream()
                .filter(u -> u.getId_artigo().equals(id))
                .findFirst()
                .orElseThrow( () -> new IllegalArgumentException("Artigo não encontrado no método: buscarArtigoPorId com o ID: " + id));
    }

    private Long generateNextId() {
        Long maxId = artigos.stream()
                .mapToLong(Artigo::getId_artigo)
                .max()
                .orElse(0L);
        return maxId + 1;
    }
}