package fiap.com.br.MarineMentor.repository;
import fiap.com.br.MarineMentor.entity.Usuario;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsuarioRepository extends CrudRepository<Usuario, Long> {}
