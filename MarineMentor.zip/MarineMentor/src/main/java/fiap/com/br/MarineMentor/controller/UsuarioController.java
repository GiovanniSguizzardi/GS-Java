package fiap.com.br.MarineMentor.controller;

import fiap.com.br.MarineMentor.entity.Usuario;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@RestController
public class UsuarioController {

    private List<Usuario> usuarios = new ArrayList<>();

    // Método para LISTAR os USUARIOS
    @GetMapping("/usuarios")
    public List<Usuario> listarUsuarios() {
        return usuarios;
    }

    // Método para CRIAR um USUARIO novo
    @PostMapping("/usuarios/add")
    public Usuario criarUsuario(@RequestBody Usuario usuario) {
        usuario.setId_usuario( generateNextId() );
        usuarios.add(usuario);
        return usuario;
    }

    // Método para ATUALIZAR algum USUARIO
    @PutMapping("/usuarios/atualizar/{id}")
    public Usuario atualizarUsuario(@PathVariable Long id, @RequestBody Usuario usuario) {
        Usuario usuarioExistente = usuarios.stream()
                .filter(u -> u.getId_usuario().equals(id))
                .findFirst()
                .orElseThrow( () -> new IllegalArgumentException("Usuario não encontrado no método, atualizarUsuario com o ID: " + id));

        usuarioExistente.setNome(usuario.getNome());
        usuarioExistente.setEmail(usuario.getEmail());
        usuarioExistente.setSenha(usuario.getSenha());
        usuarioExistente.setData_criacao(usuario.getData_criacao());
        return usuarioExistente;
    }

    // Método para DELETAR um USUARIO
    @DeleteMapping("/usuarios/delete/{id}")
    public void excluirUsuario(@PathVariable Long id) {
        usuarios.removeIf( u -> u.getId_usuario().equals(id));
    }

    // Método para listar um USUARIO por ID especifico
    @GetMapping("/usuarios/buscarid/{id}")
    public Usuario buscarUsuarioPorId(@PathVariable Long id) {
        return usuarios.stream()
                .filter(u -> u.getId_usuario().equals(id))
                .findFirst()
                .orElseThrow( () -> new IllegalArgumentException("Usuario não encontrado no método, buscarUsuarioPorId com o ID: " + id));
    }

    private Long generateNextId() {
        Long maxId = usuarios.stream()
                .mapToLong(Usuario::getId_usuario)
                .max()
                .orElse(0L);
        return maxId + 1;
    }
}