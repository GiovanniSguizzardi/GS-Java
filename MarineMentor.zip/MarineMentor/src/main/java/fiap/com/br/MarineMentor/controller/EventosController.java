package fiap.com.br.MarineMentor.controller;

import fiap.com.br.MarineMentor.entity.Eventos;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@RestController
public class EventosController {
    private List<Eventos> eventos = new ArrayList<>();

    // Método para LISTAR os EVENTOS
    @GetMapping("/eventos")
    public List<Eventos> listarEventos() {
        return eventos;
    }

    // Método para CRIAR um EVENTO novo
    @PostMapping("/eventos/add")
    public Eventos criarEvento(@RequestBody Eventos evento) {
        evento.setId_evento( generateNextId() );
        eventos.add(evento);
        return evento;
    }

    // Método para ATUALIZAR algum EVENTO
    @PutMapping("/eventos/atualizar/{id}")
    public Eventos atualizarEvento(@PathVariable Long id, @RequestBody Eventos evento) {
        Eventos eventosExistente = eventos.stream()
                .filter(u -> u.getId_evento().equals(id))
                .findFirst()
                .orElseThrow( () -> new IllegalArgumentException("Evento não encontrado no método, atualizarEvento com o ID: " + id));

        eventosExistente.setTitulo(evento.getTitulo());
        eventosExistente.setDescricao(evento.getDescricao());
        eventosExistente.setData_inicio(evento.getData_inicio());
        eventosExistente.setData_fim(evento.getData_fim());
        eventosExistente.setLocal(evento.getLocal());
        eventosExistente.setUrl(evento.getUrl());
        return eventosExistente;
    }

    // Método para DELETAR um EVENTO
    @DeleteMapping("/eventos/delete/{id}")
    public void excluirEvento(@PathVariable Long id) {
        eventos.removeIf( u -> u.getId_evento().equals(id));
    }

    // Método para listar um EVENTO por ID especifico
    @GetMapping("/eventos/buscarid/{id}")
    public Eventos buscarEventoPorId(@PathVariable Long id) {
        return eventos.stream()
                .filter(u -> u.getId_evento().equals(id))
                .findFirst()
                .orElseThrow( () -> new IllegalArgumentException("Evento não encontrado no método, buscarEventoPorId com o ID: " + id));
    }

    private Long generateNextId() {
        Long maxId = eventos.stream()
                .mapToLong(Eventos::getId_evento)
                .max()
                .orElse(0L);
        return maxId + 1;
    }
}