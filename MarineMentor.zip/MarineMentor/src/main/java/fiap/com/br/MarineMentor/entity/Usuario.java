package fiap.com.br.MarineMentor.entity;
import lombok.Getter;
import lombok.Setter;
import javax.persistence.*;
import java.io.Serializable;
import java.sql.Date;

@Getter
@Setter
@Entity
@Table(name = "usuario")
public class Usuario implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_usuario")
    private Long id_usuario;

    @Column(name="nome", length = 100)
    private String nome;

    @Column(name="email", length = 100)
    private String email;

    @Column(name="senha", length = 100)
    private String senha;

    @Column(name="data_criacao")
    private Date data_criacao;

    //Constructor
    public Usuario(Long id_usuario, String nome, String email, String senha, Date data_criacao) {
        this.id_usuario = id_usuario;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.data_criacao = data_criacao;
    }
}