package fiap.com.br.MarineMentor.entity;
import lombok.Getter;
import lombok.Setter;
import javax.persistence.*;
import java.io.Serializable;
import java.sql.Date;

@Getter
@Setter
@Entity
@Table(name = "eventos")
public class Eventos implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_evento")
    private Long id_evento;

    @Column(name="titulo", length = 200)
    private String titulo;

    @Column(name="descricao")
    private String descricao;

    @Column(name="data_inicio")
    private Date data_inicio;

    @Column(name="data_fim")
    private Date data_fim;

    @Column(name="local", length = 200)
    private String local;

    @Column(name="url", length = 300)
    private String url;

    //Constructor
    public Eventos(Long id_evento, String titulo, String descricao, Date data_inicio, Date data_fim, String local, String url) {
        this.id_evento = id_evento;
        this.titulo = titulo;
        this.descricao = descricao;
        this.data_inicio = data_inicio;
        this.data_fim = data_fim;
        this.local = local;
        this.url = url;
    }
}
