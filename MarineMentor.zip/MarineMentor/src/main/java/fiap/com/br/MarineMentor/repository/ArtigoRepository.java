package fiap.com.br.MarineMentor.repository;
import fiap.com.br.MarineMentor.entity.Artigo;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ArtigoRepository extends CrudRepository<Artigo, Long> {}
