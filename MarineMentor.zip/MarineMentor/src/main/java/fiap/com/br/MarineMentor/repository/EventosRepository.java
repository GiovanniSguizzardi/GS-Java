package fiap.com.br.MarineMentor.repository;
import fiap.com.br.MarineMentor.entity.Eventos;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EventosRepository extends CrudRepository<Eventos, Long> {}
