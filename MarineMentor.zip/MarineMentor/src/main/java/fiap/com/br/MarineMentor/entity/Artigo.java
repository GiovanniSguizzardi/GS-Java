package fiap.com.br.MarineMentor.entity;
import lombok.Getter;
import lombok.Setter;
import javax.persistence.*;
import java.sql.Date;

@Getter
@Setter
@Entity
@Table(name = "artigos")
public class Artigo {
    @Id
    @Column(name="id_artigo")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_artigo;

    @Column(name="titulo", length = 200)
    private String titulo;

    @Column(name="conteudo")
    private String conteudo;

    @Column(name="autor", length = 100)
    private String autor;

    @Column(name="data_publicacao")
    private Date data_publicacao;

    @Column(name="visualizacoes")
    private Number visualizacoes;

    //Constructor
    public Artigo(Long id_artigo, String titulo, String conteudo, String autor, Date data_publicacao, Number visualizacoes) {
        this.id_artigo = id_artigo;
        this.titulo = titulo;
        this.conteudo = conteudo;
        this.autor = autor;
        this.data_publicacao = data_publicacao;
        this.visualizacoes = visualizacoes;
    }
}